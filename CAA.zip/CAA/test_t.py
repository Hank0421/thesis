import os
import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.utils.data import DataLoader

from common.meter import Meter
from common.utils import compute_accuracy, load_model, setup_run, by
from models.dataloader.samplers import CategoriesSampler
from models.dataloader.data_utils import dataset_builder
from models.renet import RENet

def one_hot(labels_train):
    labels_train = labels_train.cpu()
    '''a=list(set(labels_train))[0]
    b=range(5)
    c=list(zip(a,b))
    d={}
    for i in c:
        d[int(i[0])]=i[1]
    for i in range(len(labels_train)):
        labels_train[i]=d[int(labels_train[0][i])]'''
    #nKnovel = 1 + labels_train.max()
    nKnovel = 5
    labels_train_1hot_size = list(labels_train.size()) + [nKnovel,]
    labels_train_unsqueeze = labels_train.unsqueeze(dim=labels_train.dim())
    labels_train_1hot = torch.zeros(labels_train_1hot_size).scatter_(len(labels_train_1hot_size) - 1, labels_train_unsqueeze, 1)
    return labels_train_1hot

def evaluate(epoch, model, loader, args=None, set='val'):
    model.eval()

    loss_meter = Meter()
    acc_meter = Meter()

    label = torch.arange(args.way).repeat(args.query)
    #print(label)
    if torch.cuda.is_available():
        label = label.cuda()

    k = args.way * args.shot
    tqdm_gen = tqdm.tqdm(loader)
    labels_shot, label_query = label[:k],label[k:]
    labels_shot=labels_shot.view(1,labels_shot.size(0))
    label_query=label_query.view(1,label_query.size(0))

    with torch.no_grad():
        for i, (data, labels) in enumerate(tqdm_gen, 1):
            if torch.cuda.is_available():
                data = data.cuda()
            #model.module.mode = 'encoder'
            model.mode = 'encoder'
            data = model(data)
            data_shot, data_query = data[:k], data[k:]
            #print(labels.size())
            #print(labels)
            #labels_shot, label_query = labels[:k],labels[k:]
            #model.module.mode = 'cca'
            model.mode = 'cca'
            
            batch_size, num_train_examples, channels, height, width = data_shot.unsqueeze(0).repeat(args.num_gpu, 1, 1, 1, 1).size()
            num_test_examples = data_query.size(1)
            
            '''print(data_shot.unsqueeze(0).repeat(args.num_gpu, 1, 1, 1, 1).size())
            print(data_query.size())
            print(labels_shot.size())
            print(label_query.size())'''
            #d=data_shot.unsqueeze(0).repeat(args.num_gpu, 1, 1, 1, 1)
            #d=d.view(1,d.size(0),d.size(1),d.size(2),d.size(3))
            data_query=data_query.view(1,data_query.size(0),data_query.size(1),data_query.size(2),data_query.size(3))
            
            labels_shot_1hot = one_hot(labels_shot).cuda()
            label_query_1hot = one_hot(label_query).cuda()
            #print(labels_shot_1hot.size())
            #print(label_query_1hot.size())

            logits = model.test_t(data_shot.unsqueeze(0).repeat(args.num_gpu, 1, 1, 1, 1), data_query,labels_shot_1hot, label_query_1hot)
            #logits = logits.view(batch_size * num_test_examples, -1)
            #print(logits.size())
            logits=logits.squeeze()
            loss = F.cross_entropy(logits, label)
            acc = compute_accuracy(logits, label)

            loss_meter.update(loss.item())
            acc_meter.update(acc)
            tqdm_gen.set_description(f'[{set:^5}] epo:{epoch:>3} | avg.loss:{loss_meter.avg():.4f} | avg.acc:{by(acc_meter.avg())} (curr:{acc:.3f})')

    return loss_meter.avg(), acc_meter.avg(), acc_meter.confidence_interval()


def test_main(model, args):

    ''' load model '''
    model = load_model(model, os.path.join(args.save_path, 'max_acc.pth'))

    ''' define test dataset '''
    Dataset = dataset_builder(args)
    test_set = Dataset('test', args)
    sampler = CategoriesSampler(test_set.label, args.test_episode, args.way, args.shot + args.query)
    test_loader = DataLoader(test_set, batch_sampler=sampler, num_workers=8, pin_memory=True)

    ''' evaluate the model with the dataset '''
    _, test_acc, test_ci = evaluate("best", model, test_loader, args, set='test')
    print(f'[final] epo:{"best":>3} | {by(test_acc)} +- {test_ci:.3f}')

    return test_acc, test_ci


if __name__ == '__main__':
    args = setup_run(arg_mode='test')

    ''' define model '''
    model = RENet(args)
    if torch.cuda.is_available():
        model = model.cuda()
    #model = nn.DataParallel(model, device_ids=args.device_ids)

    test_main(model, args)